$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/test/java/nagwaTests/nagwaTestScenario.feature");
formatter.feature({
  "line": 2,
  "name": "NagwaTestScenario",
  "description": "I want to simulate the search for a lesson on nagwa website and count the number of questions in this worksheet",
  "id": "nagwatestscenario",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@NagwaTestScenario"
    }
  ]
});
formatter.scenarioOutline({
  "line": 6,
  "name": "Lesson search and worksheet questions count",
  "description": "",
  "id": "nagwatestscenario;lesson-search-and-worksheet-questions-count",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 5,
      "name": "@count-number-of-Worksheet-questions"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "User is located on Nagwa website",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User select his preferred language",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Search on \"\u003cLessonName\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "Select and preview second lesson in search results",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "User is able to view Worksheet and count number of questions",
  "keyword": "Then "
});
formatter.examples({
  "line": 13,
  "name": "",
  "description": "",
  "id": "nagwatestscenario;lesson-search-and-worksheet-questions-count;",
  "rows": [
    {
      "cells": [
        "LessonName"
      ],
      "line": 14,
      "id": "nagwatestscenario;lesson-search-and-worksheet-questions-count;;1"
    },
    {
      "cells": [
        "addition"
      ],
      "line": 15,
      "id": "nagwatestscenario;lesson-search-and-worksheet-questions-count;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 15,
  "name": "Lesson search and worksheet questions count",
  "description": "",
  "id": "nagwatestscenario;lesson-search-and-worksheet-questions-count;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@NagwaTestScenario"
    },
    {
      "line": 5,
      "name": "@count-number-of-Worksheet-questions"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "User is located on Nagwa website",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "User select his preferred language",
  "keyword": "When "
});
formatter.step({
  "line": 9,
  "name": "Search on \"addition\"",
  "matchedColumns": [
    0
  ],
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "Select and preview second lesson in search results",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "User is able to view Worksheet and count number of questions",
  "keyword": "Then "
});
formatter.match({
  "location": "nagwaTestScenarioSteps.user_is_located_on_Nagwa_website()"
});
formatter.result({
  "duration": 98782100,
  "status": "passed"
});
formatter.match({
  "location": "nagwaTestScenarioSteps.user_select_his_preferred_language()"
});
formatter.result({
  "duration": 711925500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "addition",
      "offset": 11
    }
  ],
  "location": "nagwaTestScenarioSteps.search_on(String)"
});
formatter.result({
  "duration": 582985500,
  "status": "passed"
});
formatter.match({
  "location": "nagwaTestScenarioSteps.select_and_preview_second_lesson_in_search_results()"
});
formatter.result({
  "duration": 2570824800,
  "status": "passed"
});
formatter.match({
  "location": "nagwaTestScenarioSteps.user_is_able_to_view_Worksheet_and_count_number_of_questions()"
});
formatter.result({
  "duration": 904385200,
  "status": "passed"
});
});