package bases;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import org.junit.Test;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.annotations.*;
import org.testng.annotations.Optional;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import utilities.Helper;

public class TestBase extends AbstractTestNGCucumberTests {
    protected static WebDriver driver;
    protected static Properties props;

    //Reports
    public static ExtentTest test;
    public static ExtentReports report;

    @BeforeSuite
    @Parameters("browser")
    public static void setUp(@Optional("chrome") String browserName) {
        //External Reports
        report = new ExtentReports(System.getProperty("user.dir")+"//ExtentReportResults.html");
        test = report.startTest("ExtentDemo");

        props = System.getProperties();

        try {
            props.load(new FileInputStream(new File("Resources/Inputs/Nagwa.properties")));
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(-1);
        }

        if (browserName.equalsIgnoreCase("chrome")) {
            System.setProperty(
                    "webdriver.chrome.driver", System.getProperty("user.dir") + "/Resources/Drivers/chromedriver.exe");
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.setUnhandledPromptBehaviour(UnexpectedAlertBehaviour.IGNORE);
            driver = new ChromeDriver(chromeOptions);

        } else if (browserName.equalsIgnoreCase("firefox")) {
            System.setProperty(
                    "webdriver.gecko.driver", System.getProperty("user.dir") + "/Resources/Drivers/geckodriver.exe");
            driver = new FirefoxDriver();
        } else if (browserName.equalsIgnoreCase("ie")) {
            DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();
            ieCapabilities.setCapability("nativeEvents", false);
            ieCapabilities.setCapability("ignoreZoomSetting", true);
            ieCapabilities.setCapability("unexpectedAlertBehaviour", "accept");
            ieCapabilities.setCapability("ignoreProtectedModeSettings", true);
            ieCapabilities.setCapability("disable-popup-blocking", true);
            ieCapabilities.setCapability("enablePersistentHover", true);
            driver = new InternetExplorerDriver(ieCapabilities);
            System.setProperty(
                    "webdriver.ie.driver", System.getProperty("user.dir") + "/Resources/Drivers/IEDriverServer32.exe");
            driver = new InternetExplorerDriver();
        }

        driver.get(props.getProperty("NagwaURL"));
        driver.manage().window().maximize();
    }

    @AfterSuite
    public void tearDown() {
        driver.quit();
        //close report
        report.endTest(test);
        report.flush();
    }

    @AfterMethod
    public void screenShotOnFailure(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {

            System.out.println("TakingScreenshot..");
            Helper.captureScreenShot(driver, result.getName());

        }
    }

}
