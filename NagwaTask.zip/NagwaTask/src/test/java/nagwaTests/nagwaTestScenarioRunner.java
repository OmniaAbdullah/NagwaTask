package nagwaTests;


import bases.TestBase;
import cucumber.api.CucumberOptions;
import org.junit.*;

@CucumberOptions(
        features = "src/test/java/nagwaTests/nagwaTestScenario.feature"
        ,plugin = {"html:reports/Consumer-Website-Report.html"}
        ,glue = {"nagwaTests"}
)

public class nagwaTestScenarioRunner  extends TestBase
{

        @Test
        public void f(){}


}
