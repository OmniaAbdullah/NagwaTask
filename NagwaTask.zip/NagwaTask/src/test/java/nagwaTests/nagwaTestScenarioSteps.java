package nagwaTests;

import bases.TestBase;
import com.relevantcodes.extentreports.LogStatus;
import cucumber.api.java.en.*;
import cucumber.api.java.gl.E;
import nagwaPages.HomePage;
import nagwaPages.lessonPage;
import nagwaPages.lessonWorksheet;
import nagwaPages.searchResults;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class nagwaTestScenarioSteps extends TestBase {
    SoftAssert softAssert;
    HomePage homePageObeject;
    searchResults searchResultsObject;
    lessonPage lessonPageObject;
    lessonWorksheet lessonWorksheetObject;
    String HomePageURL;


    @Given("^User is located on Nagwa website$")
    public void user_is_located_on_Nagwa_website() {

        HomePageURL = driver.getCurrentUrl();
        try {
            Assert.assertTrue(HomePageURL.contains("nagwa.com"));
            test.log(LogStatus.PASS, "Navigated to the Nagwa.com URL successfully");

        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error heading to nagwa home page");
        }


        // UnComment if u want to try ScreenShot method on failure
     /*
            WebElement x = driver.findElement(By.id("A"));
            x.click();
     */


    }

    @When("^User select his preferred language$")
    public void user_select_his_preferred_language() {
        homePageObeject = new HomePage(driver);
        homePageObeject.chooseLanguages(System.getProperty("selectLanguage"));

        try {
            Assert.assertTrue(driver.getCurrentUrl().contains("en"));
            test.log(LogStatus.PASS, "Navigated to the Nagwa english page successfully");

        } catch (Exception e) {
            test.log(LogStatus.FAIL, "Error heading to english home page");
        }
    }

    @When("^Search on \"([^\"]*)\"$")
    public void search_on(String LessonName) {
        homePageObeject.searchOnSpecificLesson(LessonName);
        try {
            Assert.assertTrue(driver.getCurrentUrl().contains("search/?q=addition"));
            test.log(LogStatus.PASS, "User could reach search results page successfully");

        } catch (Exception e) {
            test.log(LogStatus.FAIL, "User couldn't reach search results page");
        }

    }

    @When("^Select and preview second lesson in search results$")
    public void select_and_preview_second_lesson_in_search_results() {
        searchResultsObject = new searchResults(driver);
        searchResultsObject.selectLessonFromResults();
    }

    @Then("^User is able to view Worksheet and count number of questions$")
    public void user_is_able_to_view_Worksheet_and_count_number_of_questions() {
        lessonPageObject = new lessonPage(driver);
        lessonPageObject.openLessonWorkSheet();

        try {
            Assert.assertTrue(driver.getCurrentUrl().contains("worksheets"));
            test.log(LogStatus.PASS, "User could reach worksheets page successfully");

        } catch (Exception e) {
            test.log(LogStatus.FAIL, "User not in worksheets page");
        }
        lessonWorksheetObject = new lessonWorksheet(driver);
        test.log(LogStatus.PASS, "This Worksheet has " + lessonWorksheetObject.count() + " Questions");

    }
}
