package base.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageBase
{
    protected static WebDriver driver;
    protected static WebDriverWait wait;


    public PageBase(WebDriver driver)
    {
        PageBase.driver= driver;
        wait = new WebDriverWait(driver,60);
    }

    public void clearText(By button)
    {
        safeFind(button).clear();
    }

    public void sendText(By textBox, String text){
        safeFind(textBox).sendKeys(text);
    }

    public void sendTextByKey(By textBox, Keys enter){
        safeFind(textBox).sendKeys(enter);
    }


    public void clickButton(By button) {
        try
        {
            safeFind(button).click();
        }


        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getText(By element){
        return safeFind(element).getText();
    }



    private WebElement safeFind(By locator) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }
}
