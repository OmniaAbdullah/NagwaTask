package nagwaPages;

import base.Pages.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class lessonPage extends PageBase
{
    //Constructor
    public lessonPage(WebDriver driver) {
        super(driver);
    }

    //Locators
    private static By lessonWorkSheet = By.linkText("Lesson Worksheet");


    //Functions
    public void  openLessonWorkSheet()
    {
    clickButton(lessonWorkSheet);
    }
}
