package nagwaPages;

import base.Pages.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage extends PageBase
{
    //constructor
    public HomePage(WebDriver driver)
    {
        super(driver);
    }



    //locators
    private  static By searchIcon = By.xpath("//button[@type='button']");
    private static By searchTextArea = By.id("txt_search_query");

    //Functions
    public void chooseLanguages(String Language)
    {
        driver.findElement(By.linkText(Language)).click();
    }

    public void  searchOnSpecificLesson(String LessonName)
    {
        clickButton(searchIcon);
        sendText(searchTextArea,LessonName);
        sendTextByKey(searchTextArea, Keys.ENTER);
    }


}
