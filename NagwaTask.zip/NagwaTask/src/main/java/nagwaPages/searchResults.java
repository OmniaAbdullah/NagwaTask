package nagwaPages;

import base.Pages.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;


public class searchResults extends PageBase {

    //constructor
    public searchResults(WebDriver driver) {
        super(driver);
    }

    //locators
    private static By secondSearchResult = By.xpath("//ul/li[2]/div/a");



    //Functions
    public void selectLessonFromResults()
    {
    clickButton(secondSearchResult);


    }

}
