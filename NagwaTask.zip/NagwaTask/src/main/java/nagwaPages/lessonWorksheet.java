package nagwaPages;

import base.Pages.PageBase;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

public class lessonWorksheet extends PageBase {

    //Constructor
    public lessonWorksheet(WebDriver driver) {
        super(driver);
    }



    //Functions

    public int count()
    {
        List<WebElement> googleResults = driver.findElements(By.className("one-part-question"));
        int size = 0;
        for (WebElement loop : googleResults)
        {
            size++;
        }
        return size;
    }
}

