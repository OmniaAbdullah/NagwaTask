Script Scope / Function
-------------------------------------
search on lesson name
select second search result
Count Questions in Worksheet


Flow will be
------------------------------------
1) open nagwa.com
2) Choose a language to open the home page.
3) search for"addition"
4) select second result
5) open worksheet
6) count worksheet questions


Steps to run the script
--------------------------------------
1) Run (nagwaTestScenarioRunner)


Steps to check screenShot on failure
--------------------------------------
1) head to nagwaTestScenarioSteps file
2) uncomment the dimmed part
3) Run (nagwaTestScenarioRunner)
4) refresh the project
5) check the screenshot in ScreenShots folder


Steps to check auto generated test reports
------------------------------------------
1) Head to reports folder / Consumer-Website-Report.html
2) index.html --> Right click - open in -  browser - Chrome


Steps to check External test reports
---------------------------------------
1) ExtentReportResults.html --> Right click - open in -  browser - Chrome


Script Owner
-----------------------------------------
Omnia Abullah